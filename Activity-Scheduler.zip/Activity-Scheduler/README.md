# Activity-Scheduler
This a MERN stack (MongoDB, Express.js, React.js and Node.js) app with Bootstrap.
If you find this helpful, I would be grateful if you could give me a star.

Run this app

Clone or download this repo
Run npm install
Run npm run build
Run npm start
